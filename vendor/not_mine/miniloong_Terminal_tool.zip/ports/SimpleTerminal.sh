#!/bin/bash

export HOME=/root

progdir="$(cd "$(dirname "$0")" && pwd)"
rundir="${progdir}/SimpleTerminal"
cd "${rundir}" || exit 1
program="${rundir}/simple-terminal"
log_file="${rundir}/log.txt"

"$program" -scale 2 -font 5 > "$log_file" 2>&1

